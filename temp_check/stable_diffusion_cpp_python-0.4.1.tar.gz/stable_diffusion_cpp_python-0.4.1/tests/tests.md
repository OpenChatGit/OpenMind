```bash
pytest -s
```

```bash
pytest tests\test_txt2img.py -s; pytest tests\test_controlnet.py -s; pytest tests\test_convert_model.py -s; pytest tests\test_flux.py -s; pytest tests\test_img2img.py -s; pytest tests\test_preprocess_canny.py -s; pytest tests\test_system_info.py -s; pytest tests\test_list_maps.py -s; pytest tests\test_upscale.py -s; pytest tests\test_photomaker.py -s; pytest tests\test_photomaker_2.py -s; pytest tests\test_inpainting.py -s; pytest tests\test_chroma.py -s; pytest tests\test_edit.py -s; pytest tests/test_sd3.py -s; pytest tests\test_vid.py -s; pytest tests\test_vid_vace.py -s; pytest tests\test_multi_gpu.py -s; pytest tests\test_flex2.py -s; pytest tests\test_memory_leak.py -s; pytest tests\test_qwen_image.py -s; pytest tests\test_qwen_image_edit.py -s; pytest tests\test_z_image.py -s; pytest tests\test_ovis.py -s; pytest tests\test_flux2.py -s; 
```
